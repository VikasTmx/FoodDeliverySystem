package com.FoodDeliverySystem.Controller;

import com.FoodDeliverySystem.entity.Order;
import com.FoodDeliverySystem.entity.Restaurant;
import com.FoodDeliverySystem.Service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @GetMapping
    public List<Restaurant> getRestaurants() {
        return orderService.getRestaurants();
    }

    @PostMapping
    public Order placeOrder(@RequestBody Order order) {
        return orderService.placeOrder(order);
    }
}
