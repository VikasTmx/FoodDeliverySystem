package com.FoodDeliverySystem.Service;

import com.FoodDeliverySystem.entity.MenuIteam;
import com.FoodDeliverySystem.entity.Order;
import com.FoodDeliverySystem.entity.Restaurant;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class OrderService {

    private List<Restaurant> restaurants = new ArrayList<>();

    public OrderService() {
        // Sample data
        List<MenuIteam> menu1 = new ArrayList<>();
        menu1.add(new MenuIteam("Pizza", 10.99));
        menu1.add(new MenuIteam("Pasta", 8.49));
        restaurants.add(new Restaurant("Italian Delight", menu1));

        List<MenuIteam> menu2 = new ArrayList<>();
        menu2.add(new MenuIteam("Burger", 5.99));
        menu2.add(new MenuIteam("Fries", 2.99));
        restaurants.add(new Restaurant("Fast Bites", menu2));
    }

    public List<Restaurant> getRestaurants() {
        return restaurants;
    }

    public Order placeOrder(Order order) {
        String restaurantName = order.getRestaurantName();
        String itemName = order.getIteam().getName();

        for (Restaurant restaurant : restaurants) {
            if (restaurant.getName().equalsIgnoreCase(restaurantName)) {
                for (MenuIteam item : restaurant.getMenu()) {
                    if (item.getName().equalsIgnoreCase(itemName)) {
                        Order newOrder = new Order(restaurantName, item);
                        System.out.println("✅ Order placed: " + newOrder);
                        return newOrder;
                    }
                }
                System.out.println("❌ Item not found in menu.");
                return null;
            }
        }
        System.out.println("❌ Restaurant not found.");
        return null;
    }

    public void displayMenu() {
        for (Restaurant restaurant : restaurants) {
            System.out.println("\n🍽️ " + restaurant.getName() + " Menu:");
            for (MenuIteam item : restaurant.getMenu()) {
                System.out.println(" - " + item);
            }
        }
    }
}
