package com.FoodDeliverySystem.entity;

public class Order {
	private String restaurantName;
    private MenuIteam iteam;
    
    public Order() {}
    public Order(String restaurantName, MenuIteam iteam) {
        this.restaurantName = restaurantName;
        this.iteam = iteam;
    }
	public String getRestaurantName() {
		return restaurantName;
	}
	public void setRestaurantName(String restaurantName) {
		this.restaurantName = restaurantName;
	}
	public MenuIteam getIteam() {
		return iteam;
	}
	public void setIteam(MenuIteam iteam) {
		this.iteam = iteam;
	}
    @Override
    public String toString() {
        return "Order from " + restaurantName + ": " + iteam;
    }
    

}
