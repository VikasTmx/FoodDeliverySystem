package com.FoodDeliverySystem.entity;

import java.util.List;

public class Restaurant {
	private String name;
	private List<MenuIteam> menu;
	
	public Restaurant() {}
	public Restaurant(String name, List<MenuIteam> menu) {
	this.name = name;
	this.menu = menu;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<MenuIteam> getMenu() {
		return menu;
	}
	public void setMenu(List<MenuIteam> menu) {
		this.menu = menu;
	}
	@Override
	 public String toString() {
        return "Restaurant: " + name + ", Menu Items: " + menu.size();
    }

    

}
