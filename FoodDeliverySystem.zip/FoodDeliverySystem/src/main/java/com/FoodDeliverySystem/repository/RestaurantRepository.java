package com.FoodDeliverySystem.repository;

import com.FoodDeliverySystem.entity.MenuIteam;
import com.FoodDeliverySystem.entity.Restaurant;

import java.util.ArrayList;
import java.util.List;

public class RestaurantRepository {
	 private List<Restaurant> restaurants;

	    public RestaurantRepository() {
	        this.restaurants = new ArrayList<>();

	        // Sample Data Initialization
	        List<MenuIteam> menu1 = new ArrayList<>();
	        menu1.add(new MenuIteam("Pizza", 10.99));
	        menu1.add(new MenuIteam("Pasta", 8.49));
	        restaurants.add(new Restaurant("Italian Delight", menu1));

	        List<MenuIteam> menu2 = new ArrayList<>();
	        menu2.add(new MenuIteam("Burger", 5.99));
	        menu2.add(new MenuIteam("Fries", 2.99));
	        restaurants.add(new Restaurant("Fast Bites", menu2));
	    }

	    // Get all restaurants
	    public List<Restaurant> getAllRestaurants() {
	        return restaurants;
	    }

	    // Find restaurant by name
	    public Restaurant findByName(String name) {
	        for (Restaurant restaurant : restaurants) {
	            if (restaurant.getName().equalsIgnoreCase(name)) {
	                return restaurant;
	            }
	        }
	        return null;
	    }
}
